['taxi'] = {
    label = 'Taxi Company',
    defaultDuty = true,
    offDutyPay = false,
    grades = {
        ['0'] = {
            name = 'Recruit',
            payment = 0
        },
        ['1'] = {
            name = 'Driver',
            payment = 0
        },
        ['2'] = {
            name = 'Lead Driver',
            payment = 0
        },
        ['3'] = {
            name = 'Owner',
            isboss = true, 
            bankAuth = true,
            payment = 0
        },
    },
},