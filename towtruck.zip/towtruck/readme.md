# Script

- Hello, first of all thank you for purchasing our plugin :)
- Fivem TowTruck
- Don't forget to configure the shared/config.lua file according to your server.
- Please check the config for language translations.
- Don't forget to flatbed vehicle (download: https://www.gta5-mods.com/vehicles/mtl-flatbed-tow-truck)

# Discord: aliko.
